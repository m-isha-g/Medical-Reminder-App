package MedicalReminder.models;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Appointment implements Serializable {
    private static final long serialVersionUID = 1L;
    private String doctorName;
    private String location;
    private LocalDateTime dateTime;
    private String purpose;
    private String notes;
    private boolean completed;

    public Appointment(String doctorName, String location, LocalDateTime dateTime, String purpose) {
        this.doctorName = doctorName;
        this.location = location;
        this.dateTime = dateTime;
        this.purpose = purpose;
        this.notes = "";
        this.completed = false;
    }

    // Getters and setters
    public String getDoctorName() { return doctorName; }
    public String getLocation() { return location; }
    public LocalDateTime getDateTime() { return dateTime; }
    public String getPurpose() { return purpose; }
    public String getNotes() { return notes; }
    public boolean isCompleted() { return completed; }

    public void setDoctorName(String doctorName) {
    if (doctorName == null || doctorName.trim().isEmpty()) {
        throw new IllegalArgumentException("Doctor name cannot be null or empty");
    }
    this.doctorName = doctorName.trim();
}
    public void setLocation(String location) { this.location = location; }
    public void setDateTime(LocalDateTime dateTime) { this.dateTime = dateTime; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public void setNotes(String notes) { this.notes = notes; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    @Override
    public String toString() {
        return "With Dr. " + doctorName + " at " + dateTime + " for " + purpose;
    }
}
