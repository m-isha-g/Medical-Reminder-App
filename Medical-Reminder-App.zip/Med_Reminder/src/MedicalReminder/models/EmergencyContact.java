package MedicalReminder.models;

import java.io.Serializable;

public class EmergencyContact implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private String relationship;
    private String phoneNumber;
    private String email;
    private String address;

    public EmergencyContact(String name, String relationship, String phoneNumber) {
        this.name = name;
        this.relationship = relationship;
        this.phoneNumber = phoneNumber;
    }

    // Getters and setters
    public String getName() { return name; }
    public String getRelationship() { return relationship; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getEmail() { return email; }
    public String getAddress() { return address; }
    public void setName(String name) {
    if (name == null || name.trim().isEmpty()) {
        throw new IllegalArgumentException("Name cannot be null or empty");
    }
    this.name = name.trim();
}

public void setRelationship(String relationship) {
    if (relationship == null || relationship.trim().isEmpty()) {
        throw new IllegalArgumentException("Relationship cannot be null or empty");
    }
    this.relationship = relationship.trim();
}

public void setPhoneNumber(String phoneNumber) {
    if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
        throw new IllegalArgumentException("Phone number cannot be null or empty");
    }
    // Basic validation - you might want more comprehensive phone number validation
    if (!phoneNumber.matches("[\\d\\s()-]+")) {
        throw new IllegalArgumentException("Invalid phone number format");
    }
    this.phoneNumber = phoneNumber.trim();
}

    public void setEmail(String email) { this.email = email; }
    public void setAddress(String address) { this.address = address; }

    @Override
    public String toString() {
        return name + " (" + relationship + "): " + phoneNumber;
    }
}
