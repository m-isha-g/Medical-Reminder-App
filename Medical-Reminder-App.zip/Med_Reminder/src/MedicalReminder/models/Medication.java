package MedicalReminder.models;

import java.io.Serializable;
import java.time.LocalTime;

public class Medication implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private String dosage;
    private String frequency;
    private LocalTime timeToTake;
    private String instructions;
    private boolean active;

    public Medication(String name, String dosage, String frequency, LocalTime timeToTake, String instructions) {
        this.name = name;
        this.dosage = dosage;
        this.frequency = frequency;
        this.timeToTake = timeToTake;
        this.instructions = instructions;
        this.active = true;
    }

    // Getters and setters
    public String getName() { return name; }
    public String getDosage() { return dosage; }
    public String getFrequency() { return frequency; }
    public LocalTime getTimeToTake() { return timeToTake; }
    public String getInstructions() { return instructions; }
    public boolean isActive() { return active; }

    public void setName(String name) { this.name = name; }
    public void setDosage(String dosage) { this.dosage = dosage; }
    public void setFrequency(String frequency) { this.frequency = frequency; }
    public void setTimeToTake(LocalTime timeToTake) { this.timeToTake = timeToTake; }
    public void setInstructions(String instructions) { this.instructions = instructions; }
    public void setActive(boolean active) { this.active = active; }

    @Override
    public String toString() {
        return name + " - " + dosage + " - " + frequency + " at " + timeToTake;
    }
}
