package MedicalReminder.models;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import MedicalReminder.services.AppointmentService;
import MedicalReminder.services.MedicationService;

public class Patient extends User {
    private static final long serialVersionUID = 1L;

    
    private List<String> assignedDoctors;
    private HealthProfile healthProfile;
    private List<MedicalTip> healthTips;
    private MedicationService medicationService;
    private AppointmentService appointmentService;

    public Patient(String username, String password, String fullName, String email, String phoneNumber) {
        super(username, password, fullName, email, phoneNumber);
        this.assignedDoctors = new ArrayList<>();
        this.healthProfile = new HealthProfile();
        this.healthTips = new ArrayList<>();
        this.medicationService = new MedicationService();
        this.appointmentService = new AppointmentService();
    }

    // 🔧 Fix: Reinitialize fields if they're missing after deserialization
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        if (assignedDoctors == null) assignedDoctors = new ArrayList<>();
        if (healthProfile == null) healthProfile = new HealthProfile();
        if (healthTips == null) healthTips = new ArrayList<>();
        if (medicationService == null) medicationService = new MedicationService();
        if (appointmentService == null) appointmentService = new AppointmentService();
    }

    public MedicationService getMedicationService() {
        return medicationService;
    }

    public AppointmentService getAppointmentService() {
        return appointmentService;
    }

    public void addDoctor(String doctorUsername) {
        assignedDoctors.add(doctorUsername);
    }

    public List<String> getAssignedDoctors() {
        return assignedDoctors;
    }

    public HealthProfile getHealthProfile() {
        return healthProfile;
    }

    public void setHealthProfile(HealthProfile healthProfile) {
        this.healthProfile = healthProfile;
    }

    @Override
    public String getRole() {
        return "Patient";
    }

    public void addHealthTip(MedicalTip tip) {
        healthTips.add(tip);
    }

    public List<MedicalTip> getHealthTips() {
        return healthTips;
    }
}
