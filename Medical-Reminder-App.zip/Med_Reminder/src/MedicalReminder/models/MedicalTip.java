package MedicalReminder.models;

import java.io.Serializable;
import java.time.LocalDate;

public class MedicalTip implements Serializable {
    private static final long serialVersionUID = 1L;
    private String title;
    private String content;
    private LocalDate dateGiven;
    private String doctorName;

    public MedicalTip(String title, String content, String doctorName) {
        this.title = title;
        this.content = content;
        this.doctorName = doctorName;
        this.dateGiven = LocalDate.now();
    }

    // Getters
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public LocalDate getDateGiven() { return dateGiven; }
    public String getDoctorName() { return doctorName; }

    @Override
    public String toString() {
        return title + " (by Dr. " + doctorName + " on " + dateGiven + ")";
    }
}
