package MedicalReminder.models;

import java.io.Serializable;
import java.time.LocalDate;

public class DailyTask implements Serializable {
    private static final long serialVersionUID = 1L;
    private String description;
    private LocalDate date;
    private boolean completed;

    public DailyTask(String description, LocalDate date) {
        this.description = description;
        this.date = date;
        this.completed = false;
    }

    // Getters and setters
    public String getDescription() { return description; }
    public LocalDate getDate() { return date; }
    public boolean isCompleted() { return completed; }

    public void setDescription(String description) { this.description = description; }
    public void setDate(LocalDate date) { this.date = date; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    @Override
    public String toString() {
        return description + " - " + (completed ? "Completed" : "Pending");
    }
}
