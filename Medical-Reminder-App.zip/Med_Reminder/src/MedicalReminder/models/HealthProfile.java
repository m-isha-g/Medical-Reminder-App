package MedicalReminder.models;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class HealthProfile implements Serializable {
    private static final long serialVersionUID = 1L;
    private LocalDate birthDate;
    private String bloodType;
    private double height; // in cm
    private double weight; // in kg
    private Map<String, String> allergies;
    private Map<String, String> conditions;
    private Map<String, String> currentTreatments;

    public HealthProfile() {
        this.allergies = new HashMap<>();
        this.conditions = new HashMap<>();
        this.currentTreatments = new HashMap<>();
    }

    // Getters and setters
    public LocalDate getBirthDate() { return birthDate; }
    public String getBloodType() { return bloodType; }
    public double getHeight() { return height; }
    public double getWeight() { return weight; }
    public Map<String, String> getAllergies() { return allergies; }
    public Map<String, String> getConditions() { return conditions; }
    public Map<String, String> getCurrentTreatments() { return currentTreatments; }

    public void setBirthDate(LocalDate birthDate) { this.birthDate = birthDate; }
    public void setBloodType(String bloodType) { this.bloodType = bloodType; }
    public void setHeight(double height) { this.height = height; }
    public void setWeight(double weight) { this.weight = weight; }

    public void addAllergy(String allergen, String reaction) {
        allergies.put(allergen, reaction);
    }

    public void addCondition(String condition, String diagnosisDate) {
        conditions.put(condition, diagnosisDate);
    }

    public void addTreatment(String treatment, String startDate) {
        currentTreatments.put(treatment, startDate);
    }

    public double calculateBMI() {
        if (height <= 0) return 0;
        double heightInMeters = height / 100;
        return weight / (heightInMeters * heightInMeters);
    }
}
