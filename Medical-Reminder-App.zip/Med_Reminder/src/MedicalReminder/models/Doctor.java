package MedicalReminder.models;

import java.util.ArrayList;
import java.util.List;

public class Doctor extends User {
    private static final long serialVersionUID = 1L;
    private String specialty;
    private List<String> patients;

    public Doctor(String username, String password, String fullName, String email, String phoneNumber, String specialty) {
        super(username, password, fullName, email, phoneNumber);
        this.specialty = specialty;
        this.patients = new ArrayList<>();
    }

    public void addPatient(String patientUsername) {
        patients.add(patientUsername);
    }

    public List<String> getPatients() {
        return patients;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    @Override
    public String getRole() {
        return "Doctor";
    }
}
