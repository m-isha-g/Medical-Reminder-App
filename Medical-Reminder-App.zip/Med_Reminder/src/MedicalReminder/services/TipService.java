package MedicalReminder.services;

import MedicalReminder.models.MedicalTip;
import java.util.ArrayList;
import java.util.List;

public class TipService {
    private List<MedicalTip> tips;

    public TipService() {
        this.tips = new ArrayList<>();
    }

    public void addTip(MedicalTip tip) {
        tips.add(tip);
    }

    public boolean removeTip(MedicalTip tip) {
        return tips.remove(tip);
    }

    public List<MedicalTip> getAllTips() {
        return new ArrayList<>(tips);
    }

    public List<MedicalTip> getRecentTips(int count) {
        int size = tips.size();
        return new ArrayList<>(tips.subList(Math.max(0, size - count), size));
    }
}