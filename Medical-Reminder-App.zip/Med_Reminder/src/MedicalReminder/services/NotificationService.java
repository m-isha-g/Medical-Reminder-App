package MedicalReminder.services;

import MedicalReminder.models.Appointment;
import MedicalReminder.models.Medication;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class NotificationService implements Serializable {
    private static final long serialVersionUID = 1L;
    public List<String> getMedicationNotifications(List<Medication> medications) {
        List<String> notifications = new ArrayList<>();
        LocalTime now = LocalTime.now().truncatedTo(ChronoUnit.MINUTES);
        LocalTime soon = now.plus(15, ChronoUnit.MINUTES); // Notify 15 minutes before
        
        for (Medication med : medications) {
            if (med.isActive()) {
                LocalTime medTime = med.getTimeToTake().truncatedTo(ChronoUnit.MINUTES);
                
                // Notify if it's time to take medication or within the next 15 minutes
                if (medTime.equals(now)) {
                    notifications.add("Time to take " + med.getName() + " (" + med.getDosage() + ")");
                } else if (medTime.isAfter(now) && medTime.isBefore(soon)) {
                    long minsUntil = ChronoUnit.MINUTES.between(now, medTime);
                    notifications.add("Upcoming: Take " + med.getName() + " in " + minsUntil + " minutes");
                }
            }
        }
        
        return notifications;
    }

    public List<String> getAppointmentNotifications(List<Appointment> appointments) {
        List<String> notifications = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES);
        LocalDateTime soon = now.plus(2, ChronoUnit.HOURS); // Notify for appointments in next 2 hours
        
        for (Appointment appt : appointments) {
            if (!appt.isCompleted()) {
                LocalDateTime apptTime = appt.getDateTime().truncatedTo(ChronoUnit.MINUTES);
                
                if (apptTime.isAfter(now) && apptTime.isBefore(soon)) {
                    long hoursUntil = ChronoUnit.HOURS.between(now, apptTime);
                    long minsUntil = ChronoUnit.MINUTES.between(now, apptTime) % 60;
                    
                    String timeString;
                    if (hoursUntil > 0) {
                        timeString = hoursUntil + " hour" + (hoursUntil > 1 ? "s" : "") + 
                                   (minsUntil > 0 ? " and " + minsUntil + " minute" + (minsUntil > 1 ? "s" : "") : "");
                    } else {
                        timeString = minsUntil + " minute" + (minsUntil > 1 ? "s" : "");
                    }
                    
                    notifications.add("Upcoming appointment with " + appt.getDoctorName() + 
                            " in " + timeString + " for " + appt.getPurpose());
                }
            }
        }
        
        return notifications;
    }
}