package MedicalReminder.services;

import MedicalReminder.models.Medication;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class InteractionChecker {
    // This would normally connect to a drug interaction database
    // For demo purposes, we'll use a simple list of known interactions
    private static final List<String[]> KNOWN_INTERACTIONS = List.of(
            new String[]{"Warfarin", "Ibuprofen", "Increased risk of bleeding"},
            new String[]{"Simvastatin", "Grapefruit", "Increased risk of muscle damage"},
            new String[]{"Lithium", "Diuretics", "Increased lithium toxicity"}
    );

    public List<String> checkInteractions(List<Medication> medications) {
        List<String> interactions = new ArrayList<>();
        List<String> medicationNames = medications.stream()
                .map(Medication::getName)
                .collect(Collectors.toList());

        for (String[] interaction : KNOWN_INTERACTIONS) {
            if (medicationNames.contains(interaction[0])) {
                for (int i = 1; i < interaction.length - 1; i++) {
                    if (medicationNames.contains(interaction[i])) {
                        interactions.add(interaction[0] + " + " + interaction[i] + ": " + interaction[interaction.length - 1]);
                    }
                }
            }
        }

        return interactions;
    }
}
