package MedicalReminder.services;

import MedicalReminder.models.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class StorageService {
    private static final String DATA_FILE = "medical_reminder_data.ser";

    public void saveData(Map<String, User> users, Map<String, Patient> patients, 
                        Map<String, Doctor> doctors) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(users);
            oos.writeObject(patients);
            oos.writeObject(doctors);
        } catch (IOException e) {
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> loadData() {
        Map<String, Object> data = new HashMap<>();
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            data.put("users", ois.readObject());
            data.put("patients", ois.readObject());
            data.put("doctors", ois.readObject());
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data: " + e.getMessage());
            // Initialize empty data structures if file doesn't exist
            data.put("users", new HashMap<String, User>());
            data.put("patients", new HashMap<String, Patient>());
            data.put("doctors", new HashMap<String, Doctor>());
        }
        
        return data;
    }
}
