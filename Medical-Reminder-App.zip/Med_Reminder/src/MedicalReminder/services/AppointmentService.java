package MedicalReminder.services;

import MedicalReminder.models.Appointment;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AppointmentService implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Appointment> appointments = new ArrayList<>();
    public AppointmentService() {
        this.appointments = new ArrayList<>();
    }

    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public boolean removeAppointment(Appointment appointment) {
        return appointments.remove(appointment);
    }

    public List<Appointment> getAllAppointments() {
        return new ArrayList<>(appointments);
    }

    public List<Appointment> getUpcomingAppointments() {
        LocalDateTime now = LocalDateTime.now();
        return appointments.stream()
                .filter(a -> a.getDateTime().isAfter(now))
                .sorted((a1, a2) -> a1.getDateTime().compareTo(a2.getDateTime()))
                .collect(Collectors.toList());
    }

    public void markAppointmentCompleted(Appointment appointment) {
        appointment.setCompleted(true);
    }
}
