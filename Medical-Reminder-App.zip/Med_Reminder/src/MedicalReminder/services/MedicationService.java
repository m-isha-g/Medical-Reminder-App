package MedicalReminder.services;

import MedicalReminder.models.Medication;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.io.Serializable;

public class MedicationService implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Medication> medications = new ArrayList<>();

    public MedicationService() {
        this.medications = new ArrayList<>();
    }

    public void addMedication(Medication medication) {
        medications.add(medication);
    }

    public boolean removeMedication(Medication medication) {
        return medications.remove(medication);
    }

    public List<Medication> getAllMedications() {
        return new ArrayList<>(medications);
    }

    public List<Medication> getActiveMedications() {
        return medications.stream()
                .filter(Medication::isActive)
                .collect(Collectors.toList());
    }

    public void updateMedication(int index, Medication updatedMedication) {
        if (index >= 0 && index < medications.size()) {
            medications.set(index, updatedMedication);
        }
    }
}
