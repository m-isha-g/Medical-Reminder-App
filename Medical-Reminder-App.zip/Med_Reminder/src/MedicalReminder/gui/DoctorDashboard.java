package MedicalReminder.gui;

import MedicalReminder.models.*;
import MedicalReminder.services.StorageService;
import MedicalReminder.services.MedicationService;
import MedicalReminder.services.AppointmentService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class DoctorDashboard extends JFrame {
    private Doctor doctor;
    private Map<String, User> users;
    private Map<String, Patient> patients;
    private Map<String, Doctor> doctors;
    private StorageService storageService;
    
    public DoctorDashboard(Doctor doctor, Map<String, User> users, 
                         Map<String, Patient> patients, Map<String, Doctor> doctors,
                         StorageService storageService) {
        this.doctor = doctor;
        this.users = users;
        this.patients = patients;
        this.doctors = doctors;
        this.storageService = storageService;
        
        setTitle("Medical Reminder - Doctor Dashboard: Dr. " + doctor.getFullName());
        setSize(1000, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create menu bar
        JMenuBar menuBar = new JMenuBar();
        
        JMenu fileMenu = new JMenu("File");
        JMenuItem saveItem = new JMenuItem("Save Data");
        JMenuItem logoutItem = new JMenuItem("Logout");
        fileMenu.add(saveItem);
        fileMenu.add(logoutItem);
        
        JMenu patientMenu = new JMenu("Patients");
        JMenuItem viewPatientsItem = new JMenuItem("View My Patients");
        JMenuItem addPatientItem = new JMenuItem("Assign New Patient");
        patientMenu.add(viewPatientsItem);
        patientMenu.add(addPatientItem);
        
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        helpMenu.add(aboutItem);
        
        menuBar.add(fileMenu);
        menuBar.add(patientMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);
        
        // Main content with tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Welcome panel
        JPanel welcomePanel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Welcome, Dr. " + doctor.getFullName() + 
                " (" + doctor.getSpecialty() + ")", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel, BorderLayout.CENTER);
        
        // Quick actions panel
        JPanel quickActionsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        quickActionsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JButton viewPatientsBtn = new JButton("View My Patients");
        JButton addPatientBtn = new JButton("Assign New Patient");
        JButton sendTipBtn = new JButton("Send Health Tip");
        JButton viewScheduleBtn = new JButton("View Patient Schedules");
        
        quickActionsPanel.add(viewPatientsBtn);
        quickActionsPanel.add(addPatientBtn);
        quickActionsPanel.add(sendTipBtn);
        quickActionsPanel.add(viewScheduleBtn);
        
        welcomePanel.add(quickActionsPanel, BorderLayout.SOUTH);
        
        tabbedPane.addTab("Dashboard", welcomePanel);
        
        // Add tabbed pane to frame
        add(tabbedPane);
        
        // Event listeners
        saveItem.addActionListener(e -> {
            storageService.saveData(users, patients, doctors);
            JOptionPane.showMessageDialog(this, "Data saved successfully", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
        });
        
        logoutItem.addActionListener(e -> {
            storageService.saveData(users, patients, doctors);
            dispose();
            new LoginFrame().setVisible(true);
        });
        
        viewPatientsItem.addActionListener(e -> viewPatients());
        addPatientItem.addActionListener(e -> assignNewPatient());
        
        viewPatientsBtn.addActionListener(e -> viewPatients());
        addPatientBtn.addActionListener(e -> assignNewPatient());
        sendTipBtn.addActionListener(e -> sendHealthTip());
        viewScheduleBtn.addActionListener(e -> viewPatientSchedules());
        
        aboutItem.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                    "Medical Reminder System - Doctor Portal\nVersion 1.0\n\nA system to help doctors manage patient care.", 
                    "About", JOptionPane.INFORMATION_MESSAGE);
        });
    }
    
    private void viewPatients() {
        if (doctor.getPatients().isEmpty()) {
            JOptionPane.showMessageDialog(this, "You currently have no assigned patients.", 
                    "My Patients", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        JDialog patientDialog = new JDialog(this, "My Patients", true);
        patientDialog.setSize(800, 600);
        patientDialog.setLayout(new BorderLayout());
        
        // List of patients
        DefaultListModel<String> patientListModel = new DefaultListModel<>();
        for (String patientUsername : doctor.getPatients()) {
            Patient p = patients.get(patientUsername);
            patientListModel.addElement(p.getFullName() + " (" + p.getUsername() + ")");
        }
        
        JList<String> patientList = new JList<>(patientListModel);
        JScrollPane scrollPane = new JScrollPane(patientList);
        
        // Management tabs
        JTabbedPane managementTabs = new JTabbedPane();
        
        // Button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 6, 5, 5));
        JButton viewProfileBtn = new JButton("Health Profile");
        JButton manageMedsBtn = new JButton("Medications");
        JButton manageApptsBtn = new JButton("Appointments");
        JButton manageAllergiesBtn = new JButton("Allergies");
        JButton sendTipBtn = new JButton("Send Tip");
        JButton removeBtn = new JButton("Remove");
        
        buttonPanel.add(viewProfileBtn);
        buttonPanel.add(manageMedsBtn);
        buttonPanel.add(manageApptsBtn);
        buttonPanel.add(manageAllergiesBtn);
        buttonPanel.add(sendTipBtn);
        buttonPanel.add(removeBtn);
        
        patientDialog.add(scrollPane, BorderLayout.WEST);
        patientDialog.add(managementTabs, BorderLayout.CENTER);
        patientDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners
        viewProfileBtn.addActionListener(e -> {
            int selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex == -1) {
                JOptionPane.showMessageDialog(patientDialog, "Please select a patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String patientUsername = doctor.getPatients().get(selectedIndex);
            managementTabs.removeAll();
            managementTabs.addTab("Health Profile", 
                    new HealthProfilePanel(patients.get(patientUsername).getHealthProfile()));
        });
        
        manageMedsBtn.addActionListener(e -> {
            int selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex == -1) {
                JOptionPane.showMessageDialog(patientDialog, "Please select a patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String patientUsername = doctor.getPatients().get(selectedIndex);
            managePatientMedications(patientUsername);
        });
        
        manageApptsBtn.addActionListener(e -> {
            int selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex == -1) {
                JOptionPane.showMessageDialog(patientDialog, "Please select a patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String patientUsername = doctor.getPatients().get(selectedIndex);
            managePatientAppointments(patientUsername);
        });
        
        manageAllergiesBtn.addActionListener(e -> {
            int selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex == -1) {
                JOptionPane.showMessageDialog(patientDialog, "Please select a patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String patientUsername = doctor.getPatients().get(selectedIndex);
            managePatientAllergies(patientUsername);
        });
        
        sendTipBtn.addActionListener(e -> {
            int selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex == -1) {
                JOptionPane.showMessageDialog(patientDialog, "Please select a patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String patientUsername = doctor.getPatients().get(selectedIndex);
            sendHealthTipToPatient(patientUsername);
        });
        
        removeBtn.addActionListener(e -> {
            int selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex == -1) {
                JOptionPane.showMessageDialog(patientDialog, "Please select a patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String patientUsername = doctor.getPatients().get(selectedIndex);
            removePatient(patientUsername);
            patientListModel.remove(selectedIndex);
        });
        
        patientDialog.setVisible(true);
    }
    
    private void assignNewPatient() {
        // Get list of all patients not already assigned to this doctor
        List<Patient> availablePatients = new ArrayList<>();
        for (Patient p : patients.values()) {
            if (!doctor.getPatients().contains(p.getUsername())) {
                availablePatients.add(p);
            }
        }
        
        if (availablePatients.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No available patients to assign.", 
                    "No Patients", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        JDialog assignDialog = new JDialog(this, "Assign New Patient", true);
        assignDialog.setSize(500, 400);
        assignDialog.setLayout(new BorderLayout());
        
        DefaultListModel<String> patientListModel = new DefaultListModel<>();
        for (Patient p : availablePatients) {
            patientListModel.addElement(p.getFullName() + " (" + p.getUsername() + ")");
        }
        
        JList<String> patientList = new JList<>(patientListModel);
        JScrollPane scrollPane = new JScrollPane(patientList);
        
        JButton assignBtn = new JButton("Assign Selected Patient");
        
        assignDialog.add(scrollPane, BorderLayout.CENTER);
        assignDialog.add(assignBtn, BorderLayout.SOUTH);
        
        assignBtn.addActionListener(e -> {
            int selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex == -1) {
                JOptionPane.showMessageDialog(assignDialog, "Please select a patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            Patient selectedPatient = availablePatients.get(selectedIndex);
            doctor.addPatient(selectedPatient.getUsername());
            selectedPatient.addDoctor(doctor.getUsername());
            
            JOptionPane.showMessageDialog(assignDialog, 
                    "Successfully assigned " + selectedPatient.getFullName() + " to your care.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            
            storageService.saveData(users, patients, doctors);
            assignDialog.dispose();
        });
        
        assignDialog.setVisible(true);
    }
    
private void managePatientMedications(JList<String> patientList) {
    Patient patient = getSelectedPatient(patientList);
    if (patient == null) return;

    openMedicationDialog(patient);
}

// Overload for String patientUsername
private void managePatientMedications(String patientUsername) {
    Patient patient = patients.get(patientUsername);
    if (patient == null) return;

    openMedicationDialog(patient);
}

// Overload for String patientUsername for appointments
private void managePatientAppointments(String patientUsername) {
    Patient patient = patients.get(patientUsername);
    if (patient == null) return;

    JDialog dialog = new JDialog(this, "Manage Appointments: " + patient.getFullName(), true);
    dialog.setSize(700, 500);
    dialog.setLayout(new BorderLayout());

    DefaultListModel<Appointment> listModel = new DefaultListModel<>();
    patient.getAppointmentService().getAllAppointments().forEach(listModel::addElement);

    JList<Appointment> apptList = new JList<>(listModel);
    apptList.setCellRenderer(new AppointmentListRenderer());
    JScrollPane scrollPane = new JScrollPane(apptList);

    JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
    JTextField doctorField = new JTextField(doctor.getFullName());
    JTextField locationField = new JTextField();
    JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
    JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "MM/dd/yyyy HH:mm");
    dateSpinner.setEditor(dateEditor);
    JTextField purposeField = new JTextField();

    inputPanel.add(new JLabel("Doctor:"));
    inputPanel.add(doctorField);
    inputPanel.add(new JLabel("Location:"));
    inputPanel.add(locationField);
    inputPanel.add(new JLabel("Date/Time:"));
    inputPanel.add(dateSpinner);
    inputPanel.add(new JLabel("Purpose:"));
    inputPanel.add(purposeField);

    JButton addButton = new JButton("Add Appointment");
    addButton.addActionListener(e -> {
        try {
            LocalDateTime dateTime = LocalDateTime.ofInstant(
                ((java.util.Date) dateSpinner.getValue()).toInstant(),
                java.time.ZoneId.systemDefault()
            );
            Appointment appt = new Appointment(
                doctorField.getText().trim(),
                locationField.getText().trim(),
                dateTime,
                purposeField.getText().trim()
            );
            patient.getAppointmentService().addAppointment(appt);
            listModel.addElement(appt);
            clearFields(doctorField, locationField, purposeField);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Invalid input. Please check all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    JButton removeButton = new JButton("Remove Selected");
    removeButton.addActionListener(e -> {
        Appointment selected = apptList.getSelectedValue();
        if (selected != null) {
            patient.getAppointmentService().removeAppointment(selected);
            listModel.removeElement(selected);
        }
    });

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(addButton);
    buttonPanel.add(removeButton);

    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(inputPanel, BorderLayout.NORTH);
    dialog.add(buttonPanel, BorderLayout.SOUTH);
    dialog.setVisible(true);
}

// Extracted dialog logic to avoid duplication
private void openMedicationDialog(Patient patient) {
    JDialog dialog = new JDialog(this, "Manage Medications: " + patient.getFullName(), true);
    dialog.setSize(700, 500);
    dialog.setLayout(new BorderLayout());

    DefaultListModel<Medication> listModel = new DefaultListModel<>();
    patient.getMedicationService().getAllMedications().forEach(listModel::addElement);

    JList<Medication> medList = new JList<>(listModel);
    medList.setCellRenderer(new MedicationListRenderer());
    JScrollPane scrollPane = new JScrollPane(medList);

    JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
    JTextField nameField = new JTextField();
    JTextField dosageField = new JTextField();
    JTextField frequencyField = new JTextField();
    JSpinner timeSpinner = new JSpinner(new SpinnerDateModel());
    JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
    timeSpinner.setEditor(timeEditor);
    JTextArea instructionsArea = new JTextArea(2, 20);

    inputPanel.add(new JLabel("Name:"));
    inputPanel.add(nameField);
    inputPanel.add(new JLabel("Dosage:"));
    inputPanel.add(dosageField);
    inputPanel.add(new JLabel("Frequency:"));
    inputPanel.add(frequencyField);
    inputPanel.add(new JLabel("Time:"));
    inputPanel.add(timeSpinner);
    inputPanel.add(new JLabel("Instructions:"));
    inputPanel.add(new JScrollPane(instructionsArea));

    JButton addButton = new JButton("Add Medication");
    addButton.addActionListener(e -> {
        try {
            LocalTime time = LocalTime.ofInstant(
                ((java.util.Date) timeSpinner.getValue()).toInstant(), 
                java.time.ZoneId.systemDefault()
            );
            Medication med = new Medication(
                nameField.getText().trim(),
                dosageField.getText().trim(),
                frequencyField.getText().trim(),
                time,
                instructionsArea.getText().trim()
            );
            patient.getMedicationService().addMedication(med);
            listModel.addElement(med);
            clearFields(nameField, dosageField, frequencyField, instructionsArea);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Invalid input. Please check all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    JButton removeButton = new JButton("Remove Selected");
    removeButton.addActionListener(e -> {
        Medication selected = medList.getSelectedValue();
        if (selected != null) {
            patient.getMedicationService().removeMedication(selected);
            listModel.removeElement(selected);
        }
    });

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(addButton);
    buttonPanel.add(removeButton);

    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(inputPanel, BorderLayout.NORTH);
    dialog.add(buttonPanel, BorderLayout.SOUTH);
    dialog.setVisible(true);
}

private void managePatientAppointments(JList<String> patientList) {
    Patient patient = getSelectedPatient(patientList);
    if (patient == null) return;

    JDialog dialog = new JDialog(this, "Manage Appointments: " + patient.getFullName(), true);
    dialog.setSize(700, 500);
    dialog.setLayout(new BorderLayout());

    DefaultListModel<Appointment> listModel = new DefaultListModel<>();
    patient.getAppointmentService().getAllAppointments().forEach(listModel::addElement);

    JList<Appointment> apptList = new JList<>(listModel);
    apptList.setCellRenderer(new AppointmentListRenderer());
    JScrollPane scrollPane = new JScrollPane(apptList);

    JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
    JTextField doctorField = new JTextField(doctor.getFullName());
    JTextField locationField = new JTextField();
    JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
    JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "MM/dd/yyyy HH:mm");
    dateSpinner.setEditor(dateEditor);
    JTextField purposeField = new JTextField();

    inputPanel.add(new JLabel("Doctor:"));
    inputPanel.add(doctorField);
    inputPanel.add(new JLabel("Location:"));
    inputPanel.add(locationField);
    inputPanel.add(new JLabel("Date/Time:"));
    inputPanel.add(dateSpinner);
    inputPanel.add(new JLabel("Purpose:"));
    inputPanel.add(purposeField);

    JButton addButton = new JButton("Add Appointment");
    addButton.addActionListener(e -> {
        try {
            LocalDateTime dateTime = LocalDateTime.ofInstant(
                ((java.util.Date) dateSpinner.getValue()).toInstant(),
                java.time.ZoneId.systemDefault()
            );
            Appointment appt = new Appointment(
                doctorField.getText().trim(),
                locationField.getText().trim(),
                dateTime,
                purposeField.getText().trim()
            );
            patient.getAppointmentService().addAppointment(appt);
            listModel.addElement(appt);
            clearFields(doctorField, locationField, purposeField);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Invalid input. Please check all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    JButton removeButton = new JButton("Remove Selected");
    removeButton.addActionListener(e -> {
        Appointment selected = apptList.getSelectedValue();
        if (selected != null) {
            patient.getAppointmentService().removeAppointment(selected);
            listModel.removeElement(selected);
        }
    });

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(addButton);
    buttonPanel.add(removeButton);

    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(inputPanel, BorderLayout.NORTH);
    dialog.add(buttonPanel, BorderLayout.SOUTH);
    dialog.setVisible(true);
}

private void manageConditions(JList<String> patientList) {
    Patient patient = getSelectedPatient(patientList);
    if (patient == null) return;

    JDialog dialog = new JDialog(this, "Manage Conditions: " + patient.getFullName(), true);
    dialog.setSize(500, 400);
    dialog.setLayout(new BorderLayout());

    DefaultListModel<String> listModel = new DefaultListModel<>();
    patient.getHealthProfile().getConditions().forEach((k,v) -> listModel.addElement(k + " (diagnosed: " + v + ")"));

    JList<String> conditionList = new JList<>(listModel);
    JScrollPane scrollPane = new JScrollPane(conditionList);

    JPanel inputPanel = new JPanel(new GridLayout(2, 2, 5, 5));
    JTextField conditionField = new JTextField();
    JTextField dateField = new JTextField();



    JButton addButton = new JButton("Add Condition");
    addButton.addActionListener(e -> {
        String condition = conditionField.getText().trim();
        String date = dateField.getText().trim();
        if (!condition.isEmpty() && !date.isEmpty()) {
            patient.getHealthProfile().addCondition(condition, date);
            listModel.addElement(condition + " (diagnosed: " + date + ")");
            clearFields(conditionField, dateField);
        }
    });

    JButton removeButton = new JButton("Remove Selected");
    removeButton.addActionListener(e -> {
        String selected = conditionList.getSelectedValue();
        if (selected != null) {
            String condition = selected.split("\\(")[0].trim();
            patient.getHealthProfile().getConditions().remove(condition);
            listModel.removeElement(selected);
        }
    });

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(addButton);
    buttonPanel.add(removeButton);

    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(inputPanel, BorderLayout.NORTH);
    dialog.add(buttonPanel, BorderLayout.SOUTH);
    dialog.setVisible(true);
}

private void manageTreatments(JList<String> patientList) {
    Patient patient = getSelectedPatient(patientList);
    if (patient == null) return;

    JDialog dialog = new JDialog(this, "Manage Treatments: " + patient.getFullName(), true);
    dialog.setSize(500, 400);
    dialog.setLayout(new BorderLayout());

    DefaultListModel<String> listModel = new DefaultListModel<>();
    patient.getHealthProfile().getCurrentTreatments().forEach((k,v) -> listModel.addElement(k + " (started: " + v + ")"));

    JList<String> treatmentList = new JList<>(listModel);
    JScrollPane scrollPane = new JScrollPane(treatmentList);

    JPanel inputPanel = new JPanel(new GridLayout(2, 2, 5, 5));
    JTextField treatmentField = new JTextField();
    JTextField dateField = new JTextField();

    inputPanel.add(new JLabel("Treatment:"));
    inputPanel.add(treatmentField);
    inputPanel.add(new JLabel("Start Date:"));
    inputPanel.add(dateField);

    JButton addButton = new JButton("Add Treatment");
    addButton.addActionListener(e -> {
        String treatment = treatmentField.getText().trim();
        String date = dateField.getText().trim();
        if (!treatment.isEmpty() && !date.isEmpty()) {
            patient.getHealthProfile().addTreatment(treatment, date);
            listModel.addElement(treatment + " (started: " + date + ")");
            clearFields(treatmentField, dateField);
        }
    });

    JButton removeButton = new JButton("Remove Selected");
    removeButton.addActionListener(e -> {
        String selected = treatmentList.getSelectedValue();
        if (selected != null) {
            String treatment = selected.split("\\(")[0].trim();
            patient.getHealthProfile().getCurrentTreatments().remove(treatment);
            listModel.removeElement(selected);
        }
    });

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(addButton);
    buttonPanel.add(removeButton);

    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(inputPanel, BorderLayout.NORTH);
    dialog.add(buttonPanel, BorderLayout.SOUTH);
    dialog.setVisible(true);
}

// Helper methods
private Patient getSelectedPatient(JList<String> patientList) {
    int selectedIndex = patientList.getSelectedIndex();
    if (selectedIndex == -1) {
        JOptionPane.showMessageDialog(this, "Please select a patient", "Error", JOptionPane.ERROR_MESSAGE);
        return null;
    }
    // Try to extract username from the list element (format: "Full Name (username)")
    String selectedValue = patientList.getModel().getElementAt(selectedIndex);
    int startIdx = selectedValue.lastIndexOf('(');
    int endIdx = selectedValue.lastIndexOf(')');
    if (startIdx != -1 && endIdx != -1 && endIdx > startIdx) {
        String username = selectedValue.substring(startIdx + 1, endIdx);
        return patients.get(username);
    }
    return null;
}

private void clearFields(JComponent... fields) {
    for (JComponent field : fields) {
        if (field instanceof JTextField) {
            ((JTextField)field).setText("");
        } else if (field instanceof JTextArea) {
            ((JTextArea)field).setText("");
        }
    }
}

// Custom renderers
private class MedicationListRenderer extends DefaultListCellRenderer {
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
            boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof Medication) {
            Medication med = (Medication) value;
            setText(med.getName() + " - " + med.getDosage() + " at " + med.getTimeToTake());
        }
        return this;
    }
}

private class AppointmentListRenderer extends DefaultListCellRenderer {
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
            boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof Appointment) {
            Appointment appt = (Appointment) value;
            setText(appt.getDateTime() + " with " + appt.getDoctorName() + " for " + appt.getPurpose());
        }
        return this;
    }
}
    
    private void managePatientAllergies(String patientUsername) {
        Patient patient = patients.get(patientUsername);
        if (patient == null) return;

        JDialog allergyDialog = new JDialog(this, "Manage Allergies for " + patient.getFullName(), true);
        allergyDialog.setSize(600, 400);
        allergyDialog.setLayout(new BorderLayout());
        
        JPanel allergyPanel = new JPanel(new BorderLayout());
        
        // Display current allergies
        DefaultListModel<String> allergyListModel = new DefaultListModel<>();
        for (Map.Entry<String, String> entry : patient.getHealthProfile().getAllergies().entrySet()) {
            allergyListModel.addElement(entry.getKey() + ": " + entry.getValue());
        }
        JList<String> allergyList = new JList<>(allergyListModel);
        allergyPanel.add(new JScrollPane(allergyList), BorderLayout.CENTER);
        
        // Add new allergy controls
        JPanel addPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        JTextField allergenField = new JTextField();
        JTextField reactionField = new JTextField();
        JButton addBtn = new JButton("Add Allergy");
        
        addPanel.add(new JLabel("Allergen:"));
        addPanel.add(allergenField);
        addPanel.add(new JLabel("Reaction:"));
        addPanel.add(reactionField);
        
        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.add(addPanel, BorderLayout.CENTER);
        controlPanel.add(addBtn, BorderLayout.SOUTH);
        
        addBtn.addActionListener(e -> {
            String allergen = allergenField.getText().trim();
            String reaction = reactionField.getText().trim();
            
            if (allergen.isEmpty() || reaction.isEmpty()) {
                JOptionPane.showMessageDialog(allergyDialog, 
                        "Both allergen and reaction are required", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            patient.getHealthProfile().addAllergy(allergen, reaction);
            allergyListModel.addElement(allergen + ": " + reaction);
            allergenField.setText("");
            reactionField.setText("");
        });
        
        allergyPanel.add(controlPanel, BorderLayout.SOUTH);
        allergyDialog.add(allergyPanel, BorderLayout.CENTER);
        
        JButton saveBtn = new JButton("Save Changes");
        saveBtn.addActionListener(e -> {
            storageService.saveData(users, patients, doctors);
            allergyDialog.dispose();
        });
        
        allergyDialog.add(saveBtn, BorderLayout.SOUTH);
        allergyDialog.setVisible(true);
    }
    
    private void sendHealthTip() {
        if (doctor.getPatients().isEmpty()) {
            JOptionPane.showMessageDialog(this, "You have no patients to send tips to.", 
                    "No Patients", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        JDialog selectPatientsDialog = new JDialog(this, "Select Patients", true);
        selectPatientsDialog.setSize(500, 400);
        selectPatientsDialog.setLayout(new BorderLayout());
        
        DefaultListModel<String> patientListModel = new DefaultListModel<>();
        for (String username : doctor.getPatients()) {
            Patient p = patients.get(username);
            patientListModel.addElement(p.getFullName());
        }
        
        JList<String> patientList = new JList<>(patientListModel);
        patientList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollPane = new JScrollPane(patientList);
        
        JButton nextBtn = new JButton("Next");
        
        selectPatientsDialog.add(scrollPane, BorderLayout.CENTER);
        selectPatientsDialog.add(nextBtn, BorderLayout.SOUTH);
        
        nextBtn.addActionListener(e -> {
            List<String> selectedIndices = patientList.getSelectedValuesList();
            if (selectedIndices.isEmpty()) {
                JOptionPane.showMessageDialog(selectPatientsDialog, "Please select at least one patient", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            selectPatientsDialog.dispose();
            createHealthTip(patientList.getSelectedIndices());
        });
        
        selectPatientsDialog.setVisible(true);
    }
    
    private void sendHealthTipToPatient(String patientUsername) {
        createHealthTip(new int[]{doctor.getPatients().indexOf(patientUsername)});
    }
    
    private void createHealthTip(int[] patientIndices) {
        JDialog tipDialog = new JDialog(this, "Create Health Tip", true);
        tipDialog.setSize(600, 500);
        tipDialog.setLayout(new BorderLayout());
        
        JPanel formPanel = new JPanel(new BorderLayout(5, 5));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.add(new JLabel("Tip Title:"), BorderLayout.NORTH);
        JTextField titleField = new JTextField();
        titlePanel.add(titleField, BorderLayout.CENTER);
        
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.add(new JLabel("Tip Content:"), BorderLayout.NORTH);
        JTextArea contentArea = new JTextArea(10, 40);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentPanel.add(new JScrollPane(contentArea), BorderLayout.CENTER);
        
        formPanel.add(titlePanel, BorderLayout.NORTH);
        formPanel.add(contentPanel, BorderLayout.CENTER);
        
        JButton sendBtn = new JButton("Send to Selected Patients");
        
        tipDialog.add(formPanel, BorderLayout.CENTER);
        tipDialog.add(sendBtn, BorderLayout.SOUTH);
        
        sendBtn.addActionListener(e -> {
            String title = titleField.getText().trim();
            String content = contentArea.getText().trim();
            
            if (title.isEmpty() || content.isEmpty()) {
                JOptionPane.showMessageDialog(tipDialog, 
                        "Title and content are required", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            for (int index : patientIndices) {
                String patientUsername = doctor.getPatients().get(index);
                Patient patient = patients.get(patientUsername);
                
                MedicalTip newTip = new MedicalTip(title, content, doctor.getFullName());
                patient.addHealthTip(newTip);
            }
            
            storageService.saveData(users, patients, doctors);
            JOptionPane.showMessageDialog(tipDialog, 
                    "Health tip sent to " + patientIndices.length + " patients",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            tipDialog.dispose();
        });
        
        tipDialog.setVisible(true);
    }
    
    private void viewPatientSchedules() {
        if (doctor.getPatients().isEmpty()) {
            JOptionPane.showMessageDialog(this, "You have no patients to view schedules for.", 
                    "No Patients", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        JDialog scheduleDialog = new JDialog(this, "Patient Schedules", true);
        scheduleDialog.setSize(900, 600);
        scheduleDialog.setLayout(new BorderLayout());
        
        JTabbedPane tabbedPane = new JTabbedPane();
        
        for (String username : doctor.getPatients()) {
            Patient patient = patients.get(username);
            
            JPanel patientPanel = new JPanel(new GridLayout(2, 1));
            
            // Medications sub-panel
            JPanel medPanel = new JPanel(new BorderLayout());
            medPanel.setBorder(BorderFactory.createTitledBorder("Medications"));
            DefaultListModel<String> medListModel = new DefaultListModel<>();
            for (Medication med : patient.getMedicationService().getAllMedications()) {
                medListModel.addElement(med.getName() + " - " + med.getDosage() + 
                        " - " + med.getTimeToTake().toString());
            }
            JList<String> medList = new JList<>(medListModel);
            medPanel.add(new JScrollPane(medList), BorderLayout.CENTER);
            
            // Appointments sub-panel
            JPanel apptPanel = new JPanel(new BorderLayout());
            apptPanel.setBorder(BorderFactory.createTitledBorder("Appointments"));
            DefaultListModel<String> apptListModel = new DefaultListModel<>();
            for (Appointment appt : patient.getAppointmentService().getAllAppointments()) {
                apptListModel.addElement(appt.getDateTime().toString() + " - " + 
                        appt.getDoctorName() + " - " + appt.getPurpose());
            }
            JList<String> apptList = new JList<>(apptListModel);
            apptPanel.add(new JScrollPane(apptList), BorderLayout.CENTER);
            
            patientPanel.add(medPanel);
            patientPanel.add(apptPanel);
            
            tabbedPane.addTab(patient.getFullName(), patientPanel);
        }
        
        scheduleDialog.add(tabbedPane, BorderLayout.CENTER);
        scheduleDialog.setVisible(true);
    }
    
    private void removePatient(String patientUsername) {
        Patient patient = patients.get(patientUsername);
        if (patient == null) return;
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to remove " + patient.getFullName() + " from your patient list?",
                "Confirm Removal", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            doctor.getPatients().remove(patientUsername);
            patient.getAssignedDoctors().remove(doctor.getUsername());
            storageService.saveData(users, patients, doctors);
        }
    }

    private void managePatientConditions(String patientUsername) {
    Patient patient = patients.get(patientUsername);
    if (patient == null) return;

    JDialog conditionDialog = new JDialog(this, "Manage Conditions for " + patient.getFullName(), true);
    conditionDialog.setSize(600, 400);
    conditionDialog.setLayout(new BorderLayout());
    
    JPanel conditionPanel = new JPanel(new BorderLayout());
    
    // Display current conditions
    DefaultListModel<String> conditionListModel = new DefaultListModel<>();
    for (Map.Entry<String, String> entry : patient.getHealthProfile().getConditions().entrySet()) {
        conditionListModel.addElement(entry.getKey() + " (diagnosed: " + entry.getValue() + ")");
    }
    JList<String> conditionList = new JList<>(conditionListModel);
    conditionPanel.add(new JScrollPane(conditionList), BorderLayout.CENTER);
    
    // Add new condition controls
    JPanel addPanel = new JPanel(new GridLayout(2, 2, 5, 5));
    JTextField conditionField = new JTextField();
    JTextField dateField = new JTextField();
    JButton addBtn = new JButton("Add Condition");
    
    addPanel.add(new JLabel("Condition:"));
    addPanel.add(conditionField);
    addPanel.add(new JLabel("Diagnosis Date:"));
    addPanel.add(dateField);
    
    JPanel controlPanel = new JPanel(new BorderLayout());
    controlPanel.add(addPanel, BorderLayout.CENTER);
    controlPanel.add(addBtn, BorderLayout.SOUTH);
    
    addBtn.addActionListener(e -> {
        String condition = conditionField.getText().trim();
        String date = dateField.getText().trim();
        
        if (condition.isEmpty() || date.isEmpty()) {
            JOptionPane.showMessageDialog(conditionDialog, 
                    "Both condition and date are required", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        patient.getHealthProfile().addCondition(condition, date);
        conditionListModel.addElement(condition + " (diagnosed: " + date + ")");
        conditionField.setText("");
        dateField.setText("");
    });
    
    conditionPanel.add(controlPanel, BorderLayout.SOUTH);
    conditionDialog.add(conditionPanel, BorderLayout.CENTER);
    
    JButton saveBtn = new JButton("Save Changes");
    saveBtn.addActionListener(e -> {
        storageService.saveData(users, patients, doctors);
        conditionDialog.dispose();
    });
    
    conditionDialog.add(saveBtn, BorderLayout.SOUTH);
    conditionDialog.setVisible(true);
}

private void managePatientTreatments(String patientUsername) {
    Patient patient = patients.get(patientUsername);
    if (patient == null) return;

    JDialog treatmentDialog = new JDialog(this, "Manage Treatments for " + patient.getFullName(), true);
    treatmentDialog.setSize(600, 400);
    treatmentDialog.setLayout(new BorderLayout());
    
    JPanel treatmentPanel = new JPanel(new BorderLayout());
    
    // Display current treatments
    DefaultListModel<String> treatmentListModel = new DefaultListModel<>();
    for (Map.Entry<String, String> entry : patient.getHealthProfile().getCurrentTreatments().entrySet()) {
        treatmentListModel.addElement(entry.getKey() + " (started: " + entry.getValue() + ")");
    }
    JList<String> treatmentList = new JList<>(treatmentListModel);
    treatmentPanel.add(new JScrollPane(treatmentList), BorderLayout.CENTER);
    
    // Add new treatment controls
    JPanel addPanel = new JPanel(new GridLayout(2, 2, 5, 5));
    JTextField treatmentField = new JTextField();
    JTextField dateField = new JTextField();
    JButton addBtn = new JButton("Add Treatment");
    
    addPanel.add(new JLabel("Treatment:"));
    addPanel.add(treatmentField);
    addPanel.add(new JLabel("Start Date:"));
    addPanel.add(dateField);
    
    JPanel controlPanel = new JPanel(new BorderLayout());
    controlPanel.add(addPanel, BorderLayout.CENTER);
    controlPanel.add(addBtn, BorderLayout.SOUTH);
    
    addBtn.addActionListener(e -> {
        String treatment = treatmentField.getText().trim();
        String date = dateField.getText().trim();
        
        if (treatment.isEmpty() || date.isEmpty()) {
            JOptionPane.showMessageDialog(treatmentDialog, 
                    "Both treatment and date are required", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        patient.getHealthProfile().addTreatment(treatment, date);
        treatmentListModel.addElement(treatment + " (started: " + date + ")");
        treatmentField.setText("");
        dateField.setText("");
    });
    
    treatmentPanel.add(controlPanel, BorderLayout.SOUTH);
    treatmentDialog.add(treatmentPanel, BorderLayout.CENTER);
    
    JButton saveBtn = new JButton("Save Changes");
    saveBtn.addActionListener(e -> {
        storageService.saveData(users, patients, doctors);
        treatmentDialog.dispose();
    });
    
    treatmentDialog.add(saveBtn, BorderLayout.SOUTH);
    treatmentDialog.setVisible(true);
}
}