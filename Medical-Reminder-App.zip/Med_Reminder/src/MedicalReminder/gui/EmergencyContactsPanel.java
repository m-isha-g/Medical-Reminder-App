package MedicalReminder.gui;

import MedicalReminder.models.EmergencyContact;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class EmergencyContactsPanel extends JPanel {
    private List<EmergencyContact> contacts;
    private DefaultListModel<EmergencyContact> contactListModel;
    private JList<EmergencyContact> contactList;
    
    public EmergencyContactsPanel() {
        this.contacts = new ArrayList<>();
        setLayout(new BorderLayout());
        
        // Create some sample contacts
        createSampleContacts();
        
        // Create list model and list
        contactListModel = new DefaultListModel<>();
        contactList = new JList<>(contactListModel);
        JScrollPane scrollPane = new JScrollPane(contactList);
        
        // Load contacts
        refreshContactList();
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton addButton = new JButton("Add Contact");
        JButton editButton = new JButton("Edit Selected");
        JButton removeButton = new JButton("Remove Selected");
        JButton callButton = new JButton("Call Selected");
        
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(callButton);
        
        // Add components to panel
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewContact();
            }
        });
        
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editSelectedContact();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedContact();
            }
        });
        
        callButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                callSelectedContact();
            }
        });
    }
    
    private void createSampleContacts() {
        contacts.add(new EmergencyContact("John Smith", "Son", "555-123-4567"));
        contacts.add(new EmergencyContact("Mary Johnson", "Daughter", "555-987-6543"));
        contacts.add(new EmergencyContact("Dr. Robert Brown", "Primary Physician", "555-555-1212"));
    }
    
    private void refreshContactList() {
        contactListModel.clear();
        for (EmergencyContact contact : contacts) {
            contactListModel.addElement(contact);
        }
    }
    
    private void addNewContact() {
        JDialog addDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Add Emergency Contact", true);
        addDialog.setSize(400, 250);
        addDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        // Form fields
        panel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);
        
        panel.add(new JLabel("Relationship:"));
        JTextField relationField = new JTextField();
        panel.add(relationField);
        
        panel.add(new JLabel("Phone Number:"));
        JTextField phoneField = new JTextField();
        panel.add(phoneField);
        
        panel.add(new JLabel("Email (optional):"));
        JTextField emailField = new JTextField();
        panel.add(emailField);
        
        panel.add(new JLabel("Address (optional):"));
        JTextField addressField = new JTextField();
        panel.add(addressField);
        
        // Add button
        JButton saveButton = new JButton("Save Contact");
        panel.add(new JLabel());
        panel.add(saveButton);
        
        addDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String relation = relationField.getText().trim();
                String phone = phoneField.getText().trim();
                
                if (name.isEmpty() || relation.isEmpty() || phone.isEmpty()) {
                    JOptionPane.showMessageDialog(addDialog, 
                            "Name, relationship and phone number are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                EmergencyContact newContact = new EmergencyContact(name, relation, phone);
                String email = emailField.getText().trim();
                String address = addressField.getText().trim();
                
                if (!email.isEmpty()) newContact.setEmail(email);
                if (!address.isEmpty()) newContact.setAddress(address);
                
                contacts.add(newContact);
                refreshContactList();
                addDialog.dispose();
            }
        });
        
        addDialog.setVisible(true);
    }
    
    private void editSelectedContact() {
        EmergencyContact selected = contactList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a contact to edit", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        JDialog editDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Edit Contact", true);
        editDialog.setSize(400, 250);
        editDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        // Form fields with current values
        panel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField(selected.getName());
        panel.add(nameField);
        
        panel.add(new JLabel("Relationship:"));
        JTextField relationField = new JTextField(selected.getRelationship());
        panel.add(relationField);
        
        panel.add(new JLabel("Phone Number:"));
        JTextField phoneField = new JTextField(selected.getPhoneNumber());
        panel.add(phoneField);
        
        panel.add(new JLabel("Email:"));
        JTextField emailField = new JTextField(selected.getEmail() != null ? selected.getEmail() : "");
        panel.add(emailField);
        
        panel.add(new JLabel("Address:"));
        JTextField addressField = new JTextField(selected.getAddress() != null ? selected.getAddress() : "");
        panel.add(addressField);
        
        // Save button
        JButton saveButton = new JButton("Save Changes");
        panel.add(new JLabel());
        panel.add(saveButton);
        
        editDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String relation = relationField.getText().trim();
                String phone = phoneField.getText().trim();
                
                if (name.isEmpty() || relation.isEmpty() || phone.isEmpty()) {
                    JOptionPane.showMessageDialog(editDialog, 
                            "Name, relationship and phone number are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                selected.setName(name);
                selected.setRelationship(relation);
                selected.setPhoneNumber(phone);
                selected.setEmail(emailField.getText().trim());
                selected.setAddress(addressField.getText().trim());
                
                refreshContactList();
                editDialog.dispose();
            }
        });
        
        editDialog.setVisible(true);
    }
    
    private void removeSelectedContact() {
        EmergencyContact selected = contactList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a contact to remove", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to remove " + selected.getName() + "?", 
                "Confirm Removal", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            contacts.remove(selected);
            refreshContactList();
        }
    }
    
    private void callSelectedContact() {
        EmergencyContact selected = contactList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a contact to call", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        JOptionPane.showMessageDialog(this, 
                "Calling " + selected.getName() + " at " + selected.getPhoneNumber(), 
                "Emergency Call", JOptionPane.INFORMATION_MESSAGE);
        // In a real app, this would initiate a phone call
    }
}
