package MedicalReminder.gui;

import MedicalReminder.models.Appointment;
import MedicalReminder.services.AppointmentService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AppointmentPanel extends JPanel {
    private AppointmentService appointmentService;
    private DefaultListModel<Appointment> appointmentListModel;
    private JList<Appointment> appointmentList;
    
    public AppointmentPanel(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
        setLayout(new BorderLayout());
        
        // Create list model and list
        appointmentListModel = new DefaultListModel<>();
        appointmentList = new JList<>(appointmentListModel);
        appointmentList.setCellRenderer(new AppointmentListRenderer());
        JScrollPane scrollPane = new JScrollPane(appointmentList);
        
        // Load appointments
        refreshAppointmentList();
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton addButton = new JButton("Add Appointment");
        JButton editButton = new JButton("Edit Selected");
        JButton removeButton = new JButton("Remove Selected");
        JButton completeButton = new JButton("Mark Completed");
        
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(completeButton);
        
        // Add components to panel
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewAppointment();
            }
        });
        
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editSelectedAppointment();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedAppointment();
            }
        });
        
        completeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                markAppointmentCompleted();
            }
        });
    }
    
    private void refreshAppointmentList() {
        appointmentListModel.clear();
        for (Appointment appt : appointmentService.getAllAppointments()) {
            appointmentListModel.addElement(appt);
        }
    }
    
    private void addNewAppointment() {
        JDialog addDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Add New Appointment", true);
        addDialog.setSize(400, 350);
        addDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        // Form fields
        panel.add(new JLabel("Doctor's Name:"));
        JTextField doctorField = new JTextField();
        panel.add(doctorField);
        
        panel.add(new JLabel("Location:"));
        JTextField locationField = new JTextField();
        panel.add(locationField);
        
        panel.add(new JLabel("Date & Time:"));
        JSpinner dateTimeSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateTimeEditor = new JSpinner.DateEditor(dateTimeSpinner, "MM/dd/yyyy HH:mm");
        dateTimeSpinner.setEditor(dateTimeEditor);
        panel.add(dateTimeSpinner);
        
        panel.add(new JLabel("Purpose:"));
        JTextField purposeField = new JTextField();
        panel.add(purposeField);
        
        panel.add(new JLabel("Notes:"));
        JTextArea notesArea = new JTextArea(3, 20);
        panel.add(new JScrollPane(notesArea));
        
        // Add button
        JButton saveButton = new JButton("Save Appointment");
        panel.add(new JLabel());
        panel.add(saveButton);
        
        addDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String doctor = doctorField.getText().trim();
                String location = locationField.getText().trim();
                String purpose = purposeField.getText().trim();
                
                if (doctor.isEmpty() || location.isEmpty() || purpose.isEmpty()) {
                    JOptionPane.showMessageDialog(addDialog, 
                            "Doctor's name, location and purpose are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                LocalDateTime dateTime = LocalDateTime.ofInstant(
                        ((java.util.Date) dateTimeSpinner.getValue()).toInstant(), 
                        java.time.ZoneId.systemDefault());
                String notes = notesArea.getText().trim();
                
                Appointment newAppt = new Appointment(doctor, location, dateTime, purpose);
                newAppt.setNotes(notes);
                appointmentService.addAppointment(newAppt);
                refreshAppointmentList();
                addDialog.dispose();
            }
        });
        
        addDialog.setVisible(true);
    }
    
    private void editSelectedAppointment() {
        Appointment selected = appointmentList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to edit", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        JDialog editDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Edit Appointment", true);
        editDialog.setSize(400, 350);
        editDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        // Form fields with current values
        panel.add(new JLabel("Doctor's Name:"));
        JTextField doctorField = new JTextField(selected.getDoctorName());
        panel.add(doctorField);
        
        panel.add(new JLabel("Location:"));
        JTextField locationField = new JTextField(selected.getLocation());
        panel.add(locationField);
        
        panel.add(new JLabel("Date & Time:"));
        java.util.Date dateTime = java.util.Date.from(selected.getDateTime().atZone(
                java.time.ZoneId.systemDefault()).toInstant());
        JSpinner dateTimeSpinner = new JSpinner(new SpinnerDateModel(dateTime, null, null, java.util.Calendar.MINUTE));
        JSpinner.DateEditor dateTimeEditor = new JSpinner.DateEditor(dateTimeSpinner, "MM/dd/yyyy HH:mm");
        dateTimeSpinner.setEditor(dateTimeEditor);
        panel.add(dateTimeSpinner);
        
        panel.add(new JLabel("Purpose:"));
        JTextField purposeField = new JTextField(selected.getPurpose());
        panel.add(purposeField);
        
        panel.add(new JLabel("Notes:"));
        JTextArea notesArea = new JTextArea(selected.getNotes(), 3, 20);
        panel.add(new JScrollPane(notesArea));
        
        // Save button
        JButton saveButton = new JButton("Save Changes");
        panel.add(new JLabel());
        panel.add(saveButton);
        
        editDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String doctor = doctorField.getText().trim();
                String location = locationField.getText().trim();
                String purpose = purposeField.getText().trim();
                
                if (doctor.isEmpty() || location.isEmpty() || purpose.isEmpty()) {
                    JOptionPane.showMessageDialog(editDialog, 
                            "Doctor's name, location and purpose are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                LocalDateTime dateTime = LocalDateTime.ofInstant(
                        ((java.util.Date) dateTimeSpinner.getValue()).toInstant(), 
                        java.time.ZoneId.systemDefault());
                String notes = notesArea.getText().trim();
                
                selected.setDoctorName(doctor);
                selected.setLocation(location);
                selected.setDateTime(dateTime);
                selected.setPurpose(purpose);
                selected.setNotes(notes);
                
                refreshAppointmentList();
                editDialog.dispose();
            }
        });
        
        editDialog.setVisible(true);
    }
    
    private void removeSelectedAppointment() {
        Appointment selected = appointmentList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to remove", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to remove the appointment with " + selected.getDoctorName() + "?", 
                "Confirm Removal", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            appointmentService.removeAppointment(selected);
            refreshAppointmentList();
        }
    }
    
    private void markAppointmentCompleted() {
        Appointment selected = appointmentList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select an appointment", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        selected.setCompleted(true);
        refreshAppointmentList();
    }
    
    // Custom renderer to show completed status
    private class AppointmentListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof Appointment) {
                Appointment appt = (Appointment) value;
                setText(appt.toString());
                if (appt.isCompleted()) {
                    setForeground(Color.GRAY);
                    setText(getText() + " (Completed)");
                }
            }
            
            return this;
        }
    }
}
