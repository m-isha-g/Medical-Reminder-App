package MedicalReminder.gui;

import MedicalReminder.models.MedicalTip;
import MedicalReminder.services.TipService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TipsPanel extends JPanel {
    private TipService tipService;
    private DefaultListModel<MedicalTip> tipListModel;
    private JList<MedicalTip> tipList;
    
    public TipsPanel(TipService tipService) {
        this.tipService = tipService;
        setLayout(new BorderLayout());
        
        // Create list model and list
        tipListModel = new DefaultListModel<>();
        tipList = new JList<>(tipListModel);
        tipList.setCellRenderer(new TipListRenderer());
        JScrollPane scrollPane = new JScrollPane(tipList);
        
        // Load tips
        refreshTipList();
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton addButton = new JButton("Add Tip");
        JButton viewButton = new JButton("View Details");
        JButton removeButton = new JButton("Remove Selected");
        
        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(removeButton);
        
        // Add components to panel
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewTip();
            }
        });
        
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewSelectedTip();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedTip();
            }
        });
    }
    
    private void refreshTipList() {
        tipListModel.clear();
        for (MedicalTip tip : tipService.getAllTips()) {
            tipListModel.addElement(tip);
        }
    }
    
    private void addNewTip() {
        JDialog addDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Add New Health Tip", true);
        addDialog.setSize(500, 300);
        addDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new BorderLayout());
        
        // Form fields
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        formPanel.add(new JLabel("Tip Title:"));
        JTextField titleField = new JTextField();
        formPanel.add(titleField);
        
        formPanel.add(new JLabel("Doctor's Name:"));
        JTextField doctorField = new JTextField();
        formPanel.add(doctorField);
        
        panel.add(formPanel, BorderLayout.NORTH);
        
        panel.add(new JLabel("Tip Content:"), BorderLayout.CENTER);
        JTextArea contentArea = new JTextArea(8, 40);
        panel.add(new JScrollPane(contentArea), BorderLayout.CENTER);
        
        // Add button
        JButton saveButton = new JButton("Save Tip");
        panel.add(saveButton, BorderLayout.SOUTH);
        
        addDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String title = titleField.getText().trim();
                String doctor = doctorField.getText().trim();
                String content = contentArea.getText().trim();
                
                if (title.isEmpty() || doctor.isEmpty() || content.isEmpty()) {
                    JOptionPane.showMessageDialog(addDialog, 
                            "Title, doctor's name and content are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                MedicalTip newTip = new MedicalTip(title, content, doctor);
                tipService.addTip(newTip);
                refreshTipList();
                addDialog.dispose();
            }
        });
        
        addDialog.setVisible(true);
    }
    
    private void viewSelectedTip() {
        MedicalTip selected = tipList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a tip to view", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        JDialog viewDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Tip Details", true);
        viewDialog.setSize(500, 400);
        viewDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new BorderLayout());
        
        // Header with title and doctor
        JPanel headerPanel = new JPanel(new GridLayout(0, 1));
        headerPanel.add(new JLabel("Title: " + selected.getTitle(), JLabel.CENTER));
        headerPanel.add(new JLabel("From Dr. " + selected.getDoctorName() + " on " + 
                selected.getDateGiven(), JLabel.CENTER));
        
        panel.add(headerPanel, BorderLayout.NORTH);
        
        // Content
        JTextArea contentArea = new JTextArea(selected.getContent());
        contentArea.setEditable(false);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        panel.add(new JScrollPane(contentArea), BorderLayout.CENTER);
        
        // Close button
        JButton closeButton = new JButton("Close");
        panel.add(closeButton, BorderLayout.SOUTH);
        
        closeButton.addActionListener(e -> viewDialog.dispose());
        
        viewDialog.add(panel);
        viewDialog.setVisible(true);
    }
    
    private void removeSelectedTip() {
        MedicalTip selected = tipList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a tip to remove", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to remove the tip: " + selected.getTitle() + "?", 
                "Confirm Removal", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            tipService.removeTip(selected);
            refreshTipList();
        }
    }
    
    // Custom renderer for tips
    private class TipListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof MedicalTip) {
                MedicalTip tip = (MedicalTip) value;
                setText(tip.getTitle() + " (Dr. " + tip.getDoctorName() + ")");
            }
            
            return this;
        }
    }
}
