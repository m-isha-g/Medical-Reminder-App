package MedicalReminder.gui;

import MedicalReminder.models.DailyTask;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TasksPanel extends JPanel {
    private List<DailyTask> tasks;
    private DefaultListModel<DailyTask> taskListModel;
    private JList<DailyTask> taskList;
    
    public TasksPanel() {
        this.tasks = new ArrayList<>();
        setLayout(new BorderLayout());
        
        // Create some sample tasks
        createSampleTasks();
        
        // Create list model and list
        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setCellRenderer(new TaskListRenderer());
        JScrollPane scrollPane = new JScrollPane(taskList);
        
        // Load tasks
        refreshTaskList();
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton addButton = new JButton("Add Task");
        JButton completeButton = new JButton("Mark Complete");
        JButton removeButton = new JButton("Remove Selected");
        
        buttonPanel.add(addButton);
        buttonPanel.add(completeButton);
        buttonPanel.add(removeButton);
        
        // Add components to panel
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewTask();
            }
        });
        
        completeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                markTaskCompleted();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedTask();
            }
        });
    }
    
    private void createSampleTasks() {
        tasks.add(new DailyTask("Take morning walk", LocalDate.now()));
        tasks.add(new DailyTask("Check blood pressure", LocalDate.now()));
        tasks.add(new DailyTask("Drink 8 glasses of water", LocalDate.now()));
    }
    
    private void refreshTaskList() {
        taskListModel.clear();
        for (DailyTask task : tasks) {
            taskListModel.addElement(task);
        }
    }
    
    private void addNewTask() {
        JDialog addDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Add Daily Task", true);
        addDialog.setSize(400, 200);
        addDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        // Form fields
        panel.add(new JLabel("Task Description:"));
        JTextField descField = new JTextField();
        panel.add(descField);
        
        panel.add(new JLabel("Date:"));
        JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "MM/dd/yyyy");
        dateSpinner.setEditor(dateEditor);
        panel.add(dateSpinner);
        
        // Add button
        JButton saveButton = new JButton("Save Task");
        panel.add(new JLabel());
        panel.add(saveButton);
        
        addDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String description = descField.getText().trim();
                
                if (description.isEmpty()) {
                    JOptionPane.showMessageDialog(addDialog, 
                            "Task description is required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                LocalDate date = ((java.util.Date) dateSpinner.getValue()).toInstant()
                        .atZone(java.time.ZoneId.systemDefault())
                        .toLocalDate();
                
                DailyTask newTask = new DailyTask(description, date);
                tasks.add(newTask);
                refreshTaskList();
                addDialog.dispose();
            }
        });
        
        addDialog.setVisible(true);
    }
    
    private void markTaskCompleted() {
        DailyTask selected = taskList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a task", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        selected.setCompleted(!selected.isCompleted());
        refreshTaskList();
    }
    
    private void removeSelectedTask() {
        DailyTask selected = taskList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a task to remove", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to remove this task?", 
                "Confirm Removal", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            tasks.remove(selected);
            refreshTaskList();
        }
    }
    
    // Custom renderer to show completed status
    private class TaskListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof DailyTask) {
                DailyTask task = (DailyTask) value;
                setText(task.getDescription() + " (" + task.getDate() + ")");
                if (task.isCompleted()) {
                    setForeground(Color.GRAY);
                    setText(getText() + " - Completed");
                }
            }
            
            return this;
        }
    }
}
