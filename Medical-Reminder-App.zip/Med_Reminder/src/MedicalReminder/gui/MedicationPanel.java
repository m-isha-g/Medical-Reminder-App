package MedicalReminder.gui;

import MedicalReminder.models.Medication;
import MedicalReminder.services.MedicationService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class MedicationPanel extends JPanel {
    private MedicationService medicationService;
    private DefaultListModel<Medication> medicationListModel;
    private JList<Medication> medicationList;
    
    public MedicationPanel(MedicationService medicationService) {
        this.medicationService = medicationService;
        setLayout(new BorderLayout());
        
        // Create list model and list
        medicationListModel = new DefaultListModel<>();
        medicationList = new JList<>(medicationListModel);
        medicationList.setCellRenderer(new MedicationListRenderer());
        JScrollPane scrollPane = new JScrollPane(medicationList);
        
        // Load medications
        refreshMedicationList();
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton addButton = new JButton("Add Medication");
        JButton editButton = new JButton("Edit Selected");
        JButton removeButton = new JButton("Remove Selected");
        JButton toggleButton = new JButton("Toggle Active");
        
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(toggleButton);
        
        // Add components to panel
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewMedication();
            }
        });
        
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editSelectedMedication();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedMedication();
            }
        });
        
        toggleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleMedicationStatus();
            }
        });
    }
    
    private void refreshMedicationList() {
        medicationListModel.clear();
        for (Medication med : medicationService.getAllMedications()) {
            medicationListModel.addElement(med);
        }
    }
    
    private void addNewMedication() {
        JDialog addDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Add New Medication", true);
        addDialog.setSize(400, 300);
        addDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        // Form fields
        panel.add(new JLabel("Medication Name:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);
        
        panel.add(new JLabel("Dosage:"));
        JTextField dosageField = new JTextField();
        panel.add(dosageField);
        
        panel.add(new JLabel("Frequency:"));
        JComboBox<String> frequencyCombo = new JComboBox<>(
                new String[]{"Once daily", "Twice daily", "Three times daily", 
                            "Every 4 hours", "Every 6 hours", "Weekly", "As needed"});
        panel.add(frequencyCombo);
        
        panel.add(new JLabel("Time to Take:"));
        JSpinner timeSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
        timeSpinner.setEditor(timeEditor);
        panel.add(timeSpinner);
        
        panel.add(new JLabel("Special Instructions:"));
        JTextArea instructionsArea = new JTextArea(3, 20);
        panel.add(new JScrollPane(instructionsArea));
        
        // Add button
        JButton saveButton = new JButton("Save Medication");
        panel.add(new JLabel());
        panel.add(saveButton);
        
        addDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String dosage = dosageField.getText().trim();
                
                if (name.isEmpty() || dosage.isEmpty()) {
                    JOptionPane.showMessageDialog(addDialog, 
                            "Medication name and dosage are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                String frequency = (String) frequencyCombo.getSelectedItem();
                LocalTime time = LocalTime.ofInstant(
                        ((java.util.Date) timeSpinner.getValue()).toInstant(), 
                        java.time.ZoneId.systemDefault());
                String instructions = instructionsArea.getText().trim();
                
                Medication newMed = new Medication(name, dosage, frequency, time, instructions);
                medicationService.addMedication(newMed);
                refreshMedicationList();
                addDialog.dispose();
            }
        });
        
        addDialog.setVisible(true);
    }
    
    private void editSelectedMedication() {
        Medication selected = medicationList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a medication to edit", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        JDialog editDialog = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this), "Edit Medication", true);
        editDialog.setSize(400, 300);
        editDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        // Form fields with current values
        panel.add(new JLabel("Medication Name:"));
        JTextField nameField = new JTextField(selected.getName());
        panel.add(nameField);
        
        panel.add(new JLabel("Dosage:"));
        JTextField dosageField = new JTextField(selected.getDosage());
        panel.add(dosageField);
        
        panel.add(new JLabel("Frequency:"));
        JComboBox<String> frequencyCombo = new JComboBox<>(
                new String[]{"Once daily", "Twice daily", "Three times daily", 
                            "Every 4 hours", "Every 6 hours", "Weekly", "As needed"});
        frequencyCombo.setSelectedItem(selected.getFrequency());
        panel.add(frequencyCombo);
        
        panel.add(new JLabel("Time to Take:"));
        java.util.Date time = java.util.Date.from(selected.getTimeToTake().atDate(
                java.time.LocalDate.now()).atZone(java.time.ZoneId.systemDefault()).toInstant());
        JSpinner timeSpinner = new JSpinner(new SpinnerDateModel(time, null, null, java.util.Calendar.HOUR_OF_DAY));
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
        timeSpinner.setEditor(timeEditor);
        panel.add(timeSpinner);
        
        panel.add(new JLabel("Special Instructions:"));
        JTextArea instructionsArea = new JTextArea(selected.getInstructions(), 3, 20);
        panel.add(new JScrollPane(instructionsArea));
        
        // Save button
        JButton saveButton = new JButton("Save Changes");
        panel.add(new JLabel());
        panel.add(saveButton);
        
        editDialog.add(panel);
        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String dosage = dosageField.getText().trim();
                
                if (name.isEmpty() || dosage.isEmpty()) {
                    JOptionPane.showMessageDialog(editDialog, 
                            "Medication name and dosage are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                String frequency = (String) frequencyCombo.getSelectedItem();
                LocalTime time = LocalTime.ofInstant(
                        ((java.util.Date) timeSpinner.getValue()).toInstant(), 
                        java.time.ZoneId.systemDefault());
                String instructions = instructionsArea.getText().trim();
                
                selected.setName(name);
                selected.setDosage(dosage);
                selected.setFrequency(frequency);
                selected.setTimeToTake(time);
                selected.setInstructions(instructions);
                
                refreshMedicationList();
                editDialog.dispose();
            }
        });
        
        editDialog.setVisible(true);
    }
    
    private void removeSelectedMedication() {
        Medication selected = medicationList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a medication to remove", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to remove " + selected.getName() + "?", 
                "Confirm Removal", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            medicationService.removeMedication(selected);
            refreshMedicationList();
        }
    }
    
    private void toggleMedicationStatus() {
        Medication selected = medicationList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a medication", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        selected.setActive(!selected.isActive());
        refreshMedicationList();
    }
    
    // Custom renderer to show active/inactive status
    private class MedicationListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof Medication) {
                Medication med = (Medication) value;
                setText(med.toString());
                if (!med.isActive()) {
                    setForeground(Color.GRAY);
                    setText(getText() + " (Inactive)");
                }
            }
            
            return this;
        }
    }
}
