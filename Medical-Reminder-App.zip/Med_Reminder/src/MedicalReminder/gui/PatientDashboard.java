package MedicalReminder.gui;

import MedicalReminder.models.*;
import MedicalReminder.services.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Map;
import java.util.List;

public class PatientDashboard extends JFrame {
    private Patient patient;
    private Map<String, User> users;
    private Map<String, Patient> patients;
    private Map<String, Doctor> doctors;
    private StorageService storageService;
    
    private MedicationService medicationService;
    private AppointmentService appointmentService;
    private TipService tipService;
    private NotificationService notificationService;
    
    private JTabbedPane tabbedPane;

    public PatientDashboard(Patient patient, Map<String, User> users, 
                      Map<String, Patient> patients, Map<String, Doctor> doctors,
                      StorageService storageService) {
    this.patient = patient;
    this.users = users;
    this.patients = patients;
    this.doctors = doctors;
    this.storageService = storageService;
    
    // Initialize services with actual patient data
    this.medicationService = new MedicationService();
    this.appointmentService = new AppointmentService();
    this.tipService = new TipService();
    this.notificationService = new NotificationService();
    
    // Load actual patient data into services
    loadPatientData();
    
    setTitle("Medical Reminder - Patient Dashboard: " + patient.getFullName());
    setSize(800, 600);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    
    // ... rest of the constructor ...
    
    // Check for notifications
    checkNotifications();
}

private void loadPatientData() {
    // In a real app, this would load the actual patient's data
    // For now, we'll add some sample data
    medicationService.addMedication(new Medication("Aspirin", "81mg", "Once daily", 
            LocalTime.now().plusMinutes(5), "Take with water"));
    medicationService.addMedication(new Medication("Lisinopril", "10mg", "Once daily", 
            LocalTime.of(20, 0), "Take at bedtime"));
    
    appointmentService.addAppointment(new Appointment("Dr. Smith", "Main Clinic", 
            LocalDateTime.now().plusHours(1), "Annual checkup"));
    appointmentService.addAppointment(new Appointment("Dr. Johnson", "Cardiology", 
            LocalDateTime.now().plusDays(3), "Follow-up"));
    
    // Load health tips that were sent by doctors
    for (MedicalTip tip : patient.getHealthTips()) {
        tipService.addTip(tip);
    }
  
// Add tabs
tabbedPane = new JTabbedPane();
tabbedPane.addTab("Medications", new MedicationPanel(medicationService));
tabbedPane.addTab("Appointments", new AppointmentPanel(appointmentService));

// Create menu bar and menu items
JMenuBar menuBar = new JMenuBar();
JMenu fileMenu = new JMenu("File");
JMenu helpMenu = new JMenu("Help");

JMenuItem saveItem = new JMenuItem("Save");
JMenuItem logoutItem = new JMenuItem("Logout");
JMenuItem aboutItem = new JMenuItem("About");

fileMenu.add(saveItem);
fileMenu.add(logoutItem);
helpMenu.add(aboutItem);

menuBar.add(fileMenu);
menuBar.add(helpMenu);

setJMenuBar(menuBar);

// Health Tips Tab
DefaultListModel<MedicalTip> tipsModel = new DefaultListModel<>();
for (MedicalTip tip : patient.getHealthTips()) {
    tipsModel.addElement(tip);
}
JList<MedicalTip> tipsList = new JList<>(tipsModel);
tipsList.setCellRenderer(new DefaultListCellRenderer() {
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, 
            int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof MedicalTip) {
            MedicalTip tip = (MedicalTip) value;
            setText(tip.getTitle() + " (from Dr. " + tip.getDoctorName() + ")");
        }
        return this;
    }
});
JScrollPane tipsScrollPane = new JScrollPane(tipsList);
JPanel tipsPanel = new JPanel(new BorderLayout());
tipsPanel.add(tipsScrollPane, BorderLayout.CENTER);

// Button to view tip details
JButton viewTipBtn = new JButton("View Selected Tip");
viewTipBtn.addActionListener(e -> {
    MedicalTip selected = tipsList.getSelectedValue();
    if (selected != null) {
        JOptionPane.showMessageDialog(PatientDashboard.this, 
                selected.getContent(), 
                selected.getTitle(), JOptionPane.INFORMATION_MESSAGE);
    }
});
tipsPanel.add(viewTipBtn, BorderLayout.SOUTH);

tabbedPane.addTab("Health Tips", tipsPanel);

tabbedPane.addTab("Emergency Contacts", new EmergencyContactsPanel());
tabbedPane.addTab("Daily Tasks", new TasksPanel());
tabbedPane.addTab("Health Profile", new HealthProfilePanel(patient.getHealthProfile()));

add(tabbedPane);

// Event listeners
saveItem.addActionListener(e -> {
    storageService.saveData(users, patients, doctors);
    JOptionPane.showMessageDialog(this, "Data saved successfully", 
            "Success", JOptionPane.INFORMATION_MESSAGE);
});

logoutItem.addActionListener(e -> {
    storageService.saveData(users, patients, doctors);
    dispose();
    new LoginFrame().setVisible(true);
});

aboutItem.addActionListener(e -> {
    JOptionPane.showMessageDialog(this, 
            "Medical Reminder System\nVersion 1.0\n\nA system to help elderly patients manage their medications and appointments.", 
            "About", JOptionPane.INFORMATION_MESSAGE);
});

// End of loadPatientData()
}

// Move checkNotifications() here, as a member method of PatientDashboard
private void checkNotifications() {
    List<String> medNotifications = notificationService.getMedicationNotifications(
            medicationService.getActiveMedications());

    List<String> apptNotifications = notificationService.getAppointmentNotifications(
            appointmentService.getUpcomingAppointments());

    if (!medNotifications.isEmpty() || !apptNotifications.isEmpty()) {
        StringBuilder message = new StringBuilder("You have notifications:\n\n");

        if (!medNotifications.isEmpty()) {
            message.append("Medication Reminders:\n");
            for (String note : medNotifications) {
                message.append("- ").append(note).append("\n");
            }
            message.append("\n");
        }

        if (!apptNotifications.isEmpty()) {
            message.append("Appointment Reminders:\n");
            for (String note : apptNotifications) {
                message.append("- ").append(note).append("\n");
            }
        }

        JOptionPane.showMessageDialog(this, message.toString(),
                "Notifications", JOptionPane.INFORMATION_MESSAGE);
    }
}
}
