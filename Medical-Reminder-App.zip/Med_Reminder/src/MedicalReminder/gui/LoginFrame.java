package MedicalReminder.gui;

import MedicalReminder.models.*;
import MedicalReminder.services.StorageService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JComboBox<String> roleComboBox;
    
    private Map<String, User> users;
    private Map<String, Patient> patients;
    private Map<String, Doctor> doctors;
    private StorageService storageService;

    public LoginFrame() {
        storageService = new StorageService();
        Map<String, Object> loadedData = storageService.loadData();
        users = (Map<String, User>) loadedData.get("users");
        patients = (Map<String, Patient>) loadedData.get("patients");
        doctors = (Map<String, Doctor>) loadedData.get("doctors");

        setTitle("Medical Reminder - Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Title
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("Medical Reminder System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(titleLabel, gbc);
        
        // Role selection
        gbc.gridy++;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Role:"), gbc);
        gbc.gridx = 1;
        roleComboBox = new JComboBox<>(new String[]{"Patient", "Doctor"});
        panel.add(roleComboBox, gbc);
        
        // Username
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        usernameField = new JTextField(15);
        panel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        panel.add(passwordField, gbc);
        
        // Buttons
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        panel.add(buttonPanel, gbc);
        
        add(panel);
        
        // Event listeners
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptLogin();
            }
        });
        
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showRegistrationDialog();
            }
        });
    }
    
    private void attemptLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String role = (String) roleComboBox.getSelectedItem();
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        User user = users.get(username);
        if (user == null || !user.getPassword().equals(password)) {
            JOptionPane.showMessageDialog(this, "Invalid username or password", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!user.getRole().equals(role)) {
            JOptionPane.showMessageDialog(this, "User is not registered as a " + role, 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Successful login
        dispose();
        if (role.equals("Patient")) {
            Patient patient = patients.get(username);
            new PatientDashboard(patient, users, patients, doctors, storageService).setVisible(true);
        } else {
            Doctor doctor = doctors.get(username);
            new DoctorDashboard(doctor, users, patients, doctors, storageService).setVisible(true);
        }
    }
    
    private void showRegistrationDialog() {
        JDialog registerDialog = new JDialog(this, "Register New User", true);
        registerDialog.setSize(400, 400);
        registerDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Role selection
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Register as:"), gbc);
        gbc.gridx = 1;
        JComboBox<String> registerRoleCombo = new JComboBox<>(new String[]{"Patient", "Doctor"});
        panel.add(registerRoleCombo, gbc);
        
        // Username
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        JTextField registerUserField = new JTextField(15);
        panel.add(registerUserField, gbc);
        
        // Password
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        JPasswordField registerPassField = new JPasswordField(15);
        panel.add(registerPassField, gbc);
        
        // Full Name
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        JTextField nameField = new JTextField(15);
        panel.add(nameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        JTextField emailField = new JTextField(15);
        panel.add(emailField, gbc);
        
        // Phone
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        JTextField phoneField = new JTextField(15);
        panel.add(phoneField, gbc);
        
        // Specialty (for doctors)
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Specialty (for doctors):"), gbc);
        gbc.gridx = 1;
        JTextField specialtyField = new JTextField(15);
        panel.add(specialtyField, gbc);
        
        // Register button
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        JButton completeRegisterButton = new JButton("Complete Registration");
        panel.add(completeRegisterButton, gbc);
        
        registerDialog.add(panel);
        
        completeRegisterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String role = (String) registerRoleCombo.getSelectedItem();
                String username = registerUserField.getText().trim();
                String password = new String(registerPassField.getPassword());
                String fullName = nameField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                String specialty = specialtyField.getText().trim();
                
                if (username.isEmpty() || password.isEmpty() || fullName.isEmpty()) {
                    JOptionPane.showMessageDialog(registerDialog, 
                            "Username, password and full name are required", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (users.containsKey(username)) {
                    JOptionPane.showMessageDialog(registerDialog, 
                            "Username already exists", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (role.equals("Doctor") && specialty.isEmpty()) {
                    JOptionPane.showMessageDialog(registerDialog, 
                            "Specialty is required for doctors", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Create the appropriate user type
                if (role.equals("Patient")) {
                    Patient patient = new Patient(username, password, fullName, email, phone);
                    users.put(username, patient);
                    patients.put(username, patient);
                } else {
                    Doctor doctor = new Doctor(username, password, fullName, email, phone, specialty);
                    users.put(username, doctor);
                    doctors.put(username, doctor);
                }
                
                // Save data
                storageService.saveData(users, patients, doctors);
                
                JOptionPane.showMessageDialog(registerDialog, 
                        "Registration successful! Please login with your new account.", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                registerDialog.dispose();
            }
        });
        
        registerDialog.setVisible(true);
    }
}
