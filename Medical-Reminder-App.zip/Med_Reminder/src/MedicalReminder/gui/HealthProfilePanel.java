package MedicalReminder.gui;

import MedicalReminder.models.HealthProfile;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.Map;

public class HealthProfilePanel extends JPanel {
    private HealthProfile healthProfile;
    
    public HealthProfilePanel(HealthProfile healthProfile) {
        this.healthProfile = healthProfile;
        setLayout(new BorderLayout());
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Birth date
        formPanel.add(new JLabel("Date of Birth:"));
        JSpinner birthDateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor birthDateEditor = new JSpinner.DateEditor(birthDateSpinner, "MM/dd/yyyy");
        birthDateSpinner.setEditor(birthDateEditor);
        if (healthProfile.getBirthDate() != null) {
            birthDateSpinner.setValue(java.sql.Date.valueOf(healthProfile.getBirthDate()));
        }
        formPanel.add(birthDateSpinner);
        
        // Blood type
        formPanel.add(new JLabel("Blood Type:"));
        JComboBox<String> bloodTypeCombo = new JComboBox<>(
                new String[]{"", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
        if (healthProfile.getBloodType() != null) {
            bloodTypeCombo.setSelectedItem(healthProfile.getBloodType());
        }
        formPanel.add(bloodTypeCombo);
        
        // Height
        formPanel.add(new JLabel("Height (cm):"));
        JSpinner heightSpinner = new JSpinner(new SpinnerNumberModel(170, 100, 250, 1));
        heightSpinner.setValue(healthProfile.getHeight());
        formPanel.add(heightSpinner);
        
        // Weight
        formPanel.add(new JLabel("Weight (kg):"));
        JSpinner weightSpinner = new JSpinner(new SpinnerNumberModel(70, 30, 200, 1));
        weightSpinner.setValue(healthProfile.getWeight());
        formPanel.add(weightSpinner);
        
        // BMI display
        formPanel.add(new JLabel("BMI:"));
        JLabel bmiLabel = new JLabel(String.format("%.1f", healthProfile.calculateBMI()));
        formPanel.add(bmiLabel);
        
        // Save button
        JButton saveButton = new JButton("Save Profile");
        formPanel.add(new JLabel());
        formPanel.add(saveButton);
        
        // Allergies panel
        JPanel allergiesPanel = createKeyValuePanel("Allergies", healthProfile.getAllergies());
        
        // Conditions panel
        JPanel conditionsPanel = createKeyValuePanel("Medical Conditions", healthProfile.getConditions());
        
        // Treatments panel
        JPanel treatmentsPanel = createKeyValuePanel("Current Treatments", healthProfile.getCurrentTreatments());
        
        // Tabbed pane for additional info
        JTabbedPane infoTabs = new JTabbedPane();
        infoTabs.addTab("Allergies", allergiesPanel);
        infoTabs.addTab("Conditions", conditionsPanel);
        infoTabs.addTab("Treatments", treatmentsPanel);
        
        // Add components to main panel
        add(formPanel, BorderLayout.NORTH);
        add(infoTabs, BorderLayout.CENTER);
        
        // Event listeners
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LocalDate birthDate = ((java.util.Date) birthDateSpinner.getValue()).toInstant()
                        .atZone(java.time.ZoneId.systemDefault())
                        .toLocalDate();
                String bloodType = (String) bloodTypeCombo.getSelectedItem();
                double height = (double) heightSpinner.getValue();
                double weight = (double) weightSpinner.getValue();
                
                healthProfile.setBirthDate(birthDate);
                healthProfile.setBloodType(bloodType);
                healthProfile.setHeight(height);
                healthProfile.setWeight(weight);
                
                bmiLabel.setText(String.format("%.1f", healthProfile.calculateBMI()));
                
                JOptionPane.showMessageDialog(HealthProfilePanel.this, 
                        "Health profile saved successfully", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }
    
    // In HealthProfilePanel.java, add these methods:

protected void addAllergy(String allergen, String reaction) {
    healthProfile.addAllergy(allergen, reaction);
    refreshAllergiesList();
}

protected void addCondition(String condition, String diagnosisDate) {
    healthProfile.addCondition(condition, diagnosisDate);
    refreshConditionsList();
}

protected void addTreatment(String treatment, String startDate) {
    healthProfile.addTreatment(treatment, startDate);
    refreshTreatmentsList();
}

private void refreshAllergiesList() {
    // Implementation to refresh allergies list display
}

private void refreshConditionsList() {
    // Implementation to refresh conditions list display
}

private void refreshTreatmentsList() {
    // Implementation to refresh treatments list display
}
    private JPanel createKeyValuePanel(String title, Map<String, String> data) {
        JPanel panel = new JPanel(new BorderLayout());
        
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (Map.Entry<String, String> entry : data.entrySet()) {
            listModel.addElement(entry.getKey() + ": " + entry.getValue());
        }
        
        JList<String> list = new JList<>(listModel);
        panel.add(new JScrollPane(list), BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        
        JButton addButton = new JButton("Add " + title);
        JButton removeButton = new JButton("Remove Selected");
        
        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners would be added here for adding/removing items
        // Implementation omitted for brevity
        
        return panel;
    }
}
